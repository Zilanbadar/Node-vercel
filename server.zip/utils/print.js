const print = (...args) => {
    console.log(...args);
    }
export default print;
